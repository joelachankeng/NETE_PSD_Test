import "./js/index";

import "./sass/style.scss";
import "./tailwind.css";